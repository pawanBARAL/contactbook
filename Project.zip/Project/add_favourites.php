<?php
require 'config.php';
require_login();

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit;
}

$id = (int)$_GET['id'];

// ADD to favourites only
$stmt = $pdo->prepare("
    UPDATE contacts
    SET is_favourite = 1
    WHERE id = ? AND user_id = ?
");
$stmt->execute([$id, $_SESSION['user_id']]);

// Success redirect
header("Location: dashboard.php?fav_added=1");
exit;