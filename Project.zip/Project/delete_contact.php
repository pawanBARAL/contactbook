<?php
require 'config.php';
require_login();

if (isset($_GET['id'])) {
    $contact_id = (int)$_GET['id'];
    
    // Soft delete - set deleted_at timestamp instead of removing
    $stmt = $pdo->prepare('UPDATE contacts SET deleted_at = NOW() WHERE id = ? AND user_id = ?');
    $stmt->execute([$contact_id, $_SESSION['user_id']]);
    
    header('Location: view_contacts.php?deleted=1');
    exit;
}

header('Location: view_contacts.php');
exit;
?>