<?php
// setup_admin.php - One-click admin setup
session_start();

try {
    $pdo = new PDO('mysql:host=localhost;dbname=contact_book;charset=utf8mb4', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h2>Setting up Admin User...</h2>";
    
    // Add missing columns if they don't exist
    $alter_queries = [
        "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `role` ENUM('user','admin') DEFAULT 'user'",
        "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) DEFAULT 1",
        "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `security_question` TEXT",
        "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `security_answer` VARCHAR(255)",
        "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];
    
    foreach ($alter_queries as $query) {
        try {
            $pdo->exec($query);
            echo "<p>✅ Executed: " . substr($query, 0, 50) . "...</p>";
        } catch (Exception $e) {
            echo "<p>⚠️ Could not execute: " . $e->getMessage() . "</p>";
        }
    }
    
    // Create admin user with correct password
    $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("
        INSERT INTO `users` (`name`, `email`, `password`, `role`, `is_active`, `created_at`) 
        VALUES (?, ?, ?, 'admin', 1, NOW())
        ON DUPLICATE KEY UPDATE 
            `name` = VALUES(`name`),
            `password` = VALUES(`password`),
            `role` = VALUES(`role`),
            `is_active` = VALUES(`is_active`),
            `updated_at` = NOW()
    ");
    
    $stmt->execute(['Administrator', 'admin@contactbook.com', $admin_password]);
    
    echo "<p style='color: green;'>✅ Admin user created/updated successfully!</p>";
    echo "<p><strong>Login Credentials:</strong></p>";
    echo "<p>Email: <strong>admin@contactbook.com</strong></p>";
    echo "<p>Password: <strong>admin123</strong></p>";
    
    // Verify
    $admin = $pdo->query("SELECT * FROM users WHERE email = 'admin@contactbook.com'")->fetch();
    echo "<pre>Admin user details: " . print_r($admin, true) . "</pre>";
    
    echo '<p><a href="login.php" style="background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to Login</a></p>';
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>