<?php
require 'config.php';
require 'admin_header.php';
require_admin();

$errors = [];
$success_messages = [];

// Handle user actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];
    
    // Don't allow modifying the current admin user
    if ($user_id == $_SESSION['user_id']) {
        $errors[] = "You cannot modify your own account from this page.";
    } else {
        switch ($_GET['action']) {
            case 'toggle_active':
                $stmt = $pdo->prepare('UPDATE users SET is_active = NOT is_active WHERE id = ?');
                $stmt->execute([$user_id]);
                $status = $pdo->query("SELECT is_active FROM users WHERE id = $user_id")->fetchColumn();
                $action = $status ? 'activated' : 'deactivated';
                log_admin_action('user_toggle_active', "User ID: $user_id $action");
                $success_messages[] = "User $action successfully.";
                break;
                
            case 'make_admin':
                $stmt = $pdo->prepare('UPDATE users SET role = "admin" WHERE id = ?');
                $stmt->execute([$user_id]);
                log_admin_action('user_make_admin', "User ID: $user_id promoted to admin");
                $success_messages[] = "User promoted to administrator.";
                break;
                
            case 'make_user':
                $stmt = $pdo->prepare('UPDATE users SET role = "user" WHERE id = ?');
                $stmt->execute([$user_id]);
                log_admin_action('user_make_user', "User ID: $user_id demoted to regular user");
                $success_messages[] = "User changed to regular user.";
                break;
                
            case 'delete':
                $pdo->beginTransaction();
                try {
                    // Get user info for logging
                    $user_info = $pdo->query("SELECT name, email FROM users WHERE id = $user_id")->fetch();
                    
                    // Delete user's groups
                    $stmt = $pdo->prepare('DELETE FROM groups WHERE user_id = ?');
                    $stmt->execute([$user_id]);
                    
                    // Delete user's contacts and addresses (cascade should handle addresses)
                    $stmt = $pdo->prepare('DELETE FROM contacts WHERE user_id = ?');
                    $stmt->execute([$user_id]);
                    
                    // Finally delete the user
                    $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
                    $stmt->execute([$user_id]);
                    
                    $pdo->commit();
                    log_admin_action('user_delete', "User ID: $user_id deleted (Name: {$user_info['name']}, Email: {$user_info['email']})");
                    $success_messages[] = "User deleted successfully.";
                } catch (Exception $e) {
                    $pdo->rollBack();
                    error_log('User deletion failed: ' . $e->getMessage());
                    $errors[] = 'Failed to delete user. Please try again.';
                }
                break;
        }
        
        // Redirect to clear GET parameters
        if (empty($errors)) {
            header('Location: admin_users.php?success=' . urlencode(implode(', ', $success_messages)));
            exit;
        }
    }
}

// Get success messages from URL
if (isset($_GET['success'])) {
    $success_messages = array_merge($success_messages, explode(',', $_GET['success']));
}

// Search and filter functionality
$search = trim($_GET['search'] ?? '');
$role_filter = $_GET['role'] ?? '';
$status_filter = $_GET['status'] ?? '';

// Build query with filters
$where_conditions = ['1=1'];
$params = [];

if ($search) {
    $where_conditions[] = '(name LIKE ? OR email LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($role_filter && in_array($role_filter, ['user', 'admin'])) {
    $where_conditions[] = 'role = ?';
    $params[] = $role_filter;
}

if ($status_filter === 'active') {
    $where_conditions[] = 'is_active = 1';
} elseif ($status_filter === 'inactive') {
    $where_conditions[] = 'is_active = 0';
}

$where_clause = implode(' AND ', $where_conditions);

// Get total users for pagination
$total_users = $pdo->prepare("SELECT COUNT(*) FROM users WHERE $where_clause");
$total_users->execute($params);
$total_users_count = $total_users->fetchColumn();

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;
$total_pages = ceil($total_users_count / $limit);

// Get users with pagination and filters
$stmt = $pdo->prepare("
    SELECT u.*, 
           (SELECT COUNT(*) FROM contacts c WHERE c.user_id = u.id AND c.deleted_at IS NULL) as contact_count,
           (SELECT COUNT(*) FROM groups g WHERE g.user_id = u.id) as group_count
    FROM users u 
    WHERE $where_clause 
    ORDER BY u.created_at DESC 
    LIMIT ? OFFSET ?
");
$params[] = $limit;
$params[] = $offset;
$stmt->execute($params);
$users = $stmt->fetchAll();

// Get statistics for the stats bar
$stats = [
    'total' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'admins' => $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn(),
    'active' => $pdo->query("SELECT COUNT(*) FROM users WHERE is_active = 1")->fetchColumn(),
    'inactive' => $pdo->query("SELECT COUNT(*) FROM users WHERE is_active = 0")->fetchColumn(),
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin Panel</title>
    <style>
        :root {
            --primary: #5d6df7;
            --primary-dark: #4a5bd9;
            --primary-light: #e8edff;
            --secondary: #6b7280;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --light: #f8fafc;
            --dark: #1f2937;
            --darker: #111827;
            --border: #e5e7eb;
            --shadow: rgba(0, 0, 0, 0.08);
        }

        .admin-container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .page-header {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
            margin-bottom: 30px;
        }

        .page-header h1 {
            color: var(--darker);
            margin: 0 0 10px 0;
            font-size: 28px;
        }

        .page-header p {
            color: var(--secondary);
            margin: 0;
        }

        /* Stats Bar */
        .stats-bar {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px var(--shadow);
            text-align: center;
            border-left: 4px solid var(--primary);
        }

        .stat-number {
            font-size: 32px;
            font-weight: 800;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 14px;
            color: var(--secondary);
            font-weight: 600;
        }

        /* Filters */
        .filters-card {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
            margin-bottom: 25px;
        }

        .filters-form {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto;
            gap: 15px;
            align-items: end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--dark);
            font-size: 14px;
        }

        .filter-group input, .filter-group select {
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 14px;
        }

        /* Users Table */
        .users-table-card {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 20px var(--shadow);
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px 20px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        th {
            background: var(--light);
            font-weight: 600;
            color: var(--dark);
            font-size: 14px;
        }

        .user-role {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .role-admin {
            background: #dbeafe;
            color: #1e40af;
        }

        .role-user {
            background: #f3f4f6;
            color: #374151;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .status-active {
            background: #d1fae5;
            color: #065f46;
        }

        .status-inactive {
            background: #fee2e2;
            color: #991b1b;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 11px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }

        .btn-warning:hover {
            background: #d97706;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #059669;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #4b5563;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
        }

        .pagination a, .pagination span {
            padding: 8px 16px;
            background: white;
            border: 1px solid var(--border);
            border-radius: 8px;
            text-decoration: none;
            color: var(--dark);
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .pagination a:hover, .pagination a.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .pagination span {
            background: var(--light);
            color: var(--secondary);
        }

        /* Messages */
        .error {
            background: #fef2f2;
            color: var(--danger);
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #fecaca;
        }

        .success {
            background: #f0fdf4;
            color: var(--success);
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #bbf7d0;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--secondary);
        }

        .empty-state h3 {
            margin-bottom: 10px;
            color: var(--dark);
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .filters-form {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 768px) {
            .filters-form {
                grid-template-columns: 1fr;
            }
            
            .stats-bar {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            table {
                font-size: 14px;
            }
            
            th, td {
                padding: 10px 12px;
            }
        }

        @media (max-width: 480px) {
            .stats-bar {
                grid-template-columns: 1fr;
            }
        }

        .user-stats {
            font-size: 12px;
            color: var(--secondary);
            margin-top: 5px;
        }

        .current-user {
            background: #f0f9ff !important;
            border-left: 4px solid var(--primary) !important;
        }
    </style>
</head>
<body>

<main class="admin-container">
    <!-- Page Header -->
    <div class="page-header">
        <h1>Manage Users</h1>
        <p>View and manage all registered users in the system</p>
    </div>

    <!-- Success Messages -->
    <?php if (!empty($success_messages)): ?>
        <div class="success">
            <?php foreach ($success_messages as $msg): ?>
                <div>✅ <?= htmlspecialchars($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Error Messages -->
    <?php if (!empty($errors)): ?>
        <div class="error">
            <?php foreach ($errors as $error): ?>
                <div>❌ <?= htmlspecialchars($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="stats-bar">
        <div class="stat-card">
            <div class="stat-number"><?= $stats['total'] ?></div>
            <div class="stat-label">Total Users</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['admins'] ?></div>
            <div class="stat-label">Administrators</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['active'] ?></div>
            <div class="stat-label">Active Users</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['inactive'] ?></div>
            <div class="stat-label">Inactive Users</div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div style="margin-bottom: 20px; display: flex; gap: 15px; flex-wrap: wrap;">
        <a href="admin_users_add.php" class="btn btn-primary">
            <span>➕</span>
            Add New User
        </a>
        <a href="admin_dashboard.php" class="btn btn-secondary">
            <span>←</span>
            Back to Dashboard
        </a>
    </div>

    <!-- Filters -->
    <div class="filters-card">
        <form method="get" class="filters-form">
            <div class="filter-group">
                <label for="search">Search Users</label>
                <input type="text" id="search" name="search" placeholder="Search by name or email..." 
                       value="<?= htmlspecialchars($search) ?>">
            </div>
            
            <div class="filter-group">
                <label for="role">Role</label>
                <select id="role" name="role">
                    <option value="">All Roles</option>
                    <option value="user" <?= $role_filter === 'user' ? 'selected' : '' ?>>Users</option>
                    <option value="admin" <?= $role_filter === 'admin' ? 'selected' : '' ?>>Administrators</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="">All Status</option>
                    <option value="active" <?= $status_filter === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= $status_filter === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            
            <div class="filter-group">
                <button type="submit" class="btn btn-primary">Apply Filters</button>
                <?php if ($search || $role_filter || $status_filter): ?>
                    <a href="admin_users.php" class="btn btn-secondary" style="margin-top: 8px;">Clear Filters</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Users Table -->
    <div class="users-table-card">
        <?php if (empty($users)): ?>
            <div class="empty-state">
                <h3>No users found</h3>
                <p><?= ($search || $role_filter || $status_filter) ? 'Try adjusting your filters.' : 'There are no registered users in the system yet.' ?></p>
                <a href="admin_users_add.php" class="btn btn-primary" style="margin-top: 15px;">Add First User</a>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Contacts</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr class="<?= $user['id'] == $_SESSION['user_id'] ? 'current-user' : '' ?>">
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($user['name']) ?></div>
                            <div style="color: var(--secondary); font-size: 14px;"><?= htmlspecialchars($user['email']) ?></div>
                            <div class="user-stats">
                                ID: <?= $user['id'] ?> 
                                <?php if ($user['id'] == $_SESSION['user_id']): ?>
                                    <span style="color: var(--primary); font-weight: 600;">(You)</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <span class="user-role role-<?= $user['role'] ?>">
                                <?= strtoupper($user['role']) ?>
                            </span>
                        </td>
                        <td>
                            <span class="status-badge status-<?= $user['is_active'] ? 'active' : 'inactive' ?>">
                                <?= $user['is_active'] ? 'Active' : 'Inactive' ?>
                            </span>
                        </td>
                        <td>
                            <div><?= $user['contact_count'] ?> contacts</div>
                            <div class="user-stats"><?= $user['group_count'] ?> groups</div>
                        </td>
                        <td>
                            <?= date('M j, Y', strtotime($user['created_at'])) ?>
                            <div class="user-stats"><?= date('g:i A', strtotime($user['created_at'])) ?></div>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <!-- Toggle Active/Inactive -->
                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                    <a href="?action=toggle_active&id=<?= $user['id'] ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $role_filter ? '&role=' . $role_filter : '' ?><?= $status_filter ? '&status=' . $status_filter : '' ?><?= $page > 1 ? '&page=' . $page : '' ?>" 
                                       class="btn btn-sm <?= $user['is_active'] ? 'btn-warning' : 'btn-success' ?>"
                                       title="<?= $user['is_active'] ? 'Deactivate User' : 'Activate User' ?>">
                                        <?= $user['is_active'] ? '⏸️' : '▶️' ?>
                                        <?= $user['is_active'] ? 'Deactivate' : 'Activate' ?>
                                    </a>
                                <?php endif; ?>

                                <!-- Role Management -->
                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                    <?php if ($user['role'] === 'user'): ?>
                                        <a href="?action=make_admin&id=<?= $user['id'] ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $role_filter ? '&role=' . $role_filter : '' ?><?= $status_filter ? '&status=' . $status_filter : '' ?><?= $page > 1 ? '&page=' . $page : '' ?>" 
                                           class="btn btn-sm btn-primary"
                                           title="Make Administrator">
                                            ⬆️ Make Admin
                                        </a>
                                    <?php else: ?>
                                        <a href="?action=make_user&id=<?= $user['id'] ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $role_filter ? '&role=' . $role_filter : '' ?><?= $status_filter ? '&status=' . $status_filter : '' ?><?= $page > 1 ? '&page=' . $page : '' ?>" 
                                           class="btn btn-sm btn-warning"
                                           title="Make Regular User">
                                            ⬇️ Make User
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <!-- Delete User -->
                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                    <a href="?action=delete&id=<?= $user['id'] ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $role_filter ? '&role=' . $role_filter : '' ?><?= $status_filter ? '&status=' . $status_filter : '' ?><?= $page > 1 ? '&page=' . $page : '' ?>" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('WARNING: This will permanently delete user \\'<?= addslashes($user['name']) ?>\\' and ALL their contacts and data. This action cannot be undone!\\n\\nAre you sure you want to delete this user?')"
                                       title="Delete User">
                                        🗑️ Delete
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?= $page - 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $role_filter ? '&role=' . $role_filter : '' ?><?= $status_filter ? '&status=' . $status_filter : '' ?>">‹ Previous</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <?php if ($i == $page): ?>
                <span class="active"><?= $i ?></span>
            <?php else: ?>
                <a href="?page=<?= $i ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $role_filter ? '&role=' . $role_filter : '' ?><?= $status_filter ? '&status=' . $status_filter : '' ?>"><?= $i ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <a href="?page=<?= $page + 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $role_filter ? '&role=' . $role_filter : '' ?><?= $status_filter ? '&status=' . $status_filter : '' ?>">Next ›</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Results Info -->
    <?php if (!empty($users)): ?>
        <div style="text-align: center; color: var(--secondary); margin-top: 15px;">
            Showing <?= count($users) ?> of <?= $total_users_count ?> users
            <?php if ($search || $role_filter || $status_filter): ?>
                (filtered)
            <?php endif; ?>
        </div>
    <?php endif; ?>
</main>

<script>
    // Auto-submit form when filters change (optional)
    document.addEventListener('DOMContentLoaded', function() {
        const roleSelect = document.getElementById('role');
        const statusSelect = document.getElementById('status');
        
        // Uncomment below to auto-submit when filters change
        /*
        roleSelect.addEventListener('change', function() {
            this.form.submit();
        });
        
        statusSelect.addEventListener('change', function() {
            this.form.submit();
        });
        */
        
        // Add confirmation for all action links
        const actionLinks = document.querySelectorAll('a[href*="action="]');
        actionLinks.forEach(link => {
            if (!link.onclick) {
                link.addEventListener('click', function(e) {
                    const action = this.textContent.trim();
                    if (action.includes('Delete')) {
                        return confirm('Are you sure you want to perform this action?');
                    }
                });
            }
        });
    });
</script>

</body>
</html>