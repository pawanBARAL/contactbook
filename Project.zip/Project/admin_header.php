<?php
// admin_header.php - Admin navigation header

// Start session only if it isn't already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is admin
function is_admin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}
?>

<style>
/* ---------- ADMIN HEADER NAV BAR ---------- */
.admin-header {
    background: linear-gradient(135deg, #5d6df7 0%, #4a5bd9 100%);
    padding: 18px 0;
    box-shadow: 0 2px 12px rgba(0,0,0,0.15);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.admin-nav-container {
    max-width: 1250px;
    margin: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 25px;
}

.admin-site-logo {
    font-size: 24px;
    font-weight: 700;
    color: white;
    text-decoration: none;
    letter-spacing: 0.5px;
}

.admin-nav-menu {
    display: flex;
    align-items: center;
}

.admin-nav-menu a {
    margin-left: 22px;
    text-decoration: none;
    color: rgba(255,255,255,0.9);
    font-size: 15px;
    font-weight: 500;
    padding: 8px 14px;
    border-radius: 6px;
    transition: 0.25s ease;
}

.admin-nav-menu a:hover {
    background: rgba(255,255,255,0.15);
    color: white;
}

.admin-logout-btn {
    background: rgba(255,255,255,0.2);
    color: white !important;
    font-weight: 600;
}

.admin-logout-btn:hover {
    background: rgba(255,255,255,0.3);
}

.admin-badge {
    background: #10b981;
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    margin-left: 8px;
}
</style>

<!-- ---------- ADMIN HEADER SECTION ---------- -->
<header class="admin-header">
    <div class="admin-nav-container">
        <!-- Logo linking back to admin dashboard -->
        <a href="admin_dashboard.php" class="admin-site-logo">👑 Admin Panel</a>

        <!-- Admin navigation menu -->
        <nav class="admin-nav-menu">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="admin_users.php">Manage Users</a>
            <a href="admin_log.php">System Logs</a>
            <a href="dashboard.php">User View</a>
            <a href="logout.php" class="admin-logout-btn">Logout</a>
            <span class="admin-badge">ADMIN</span>
        </nav>
    </div>
</header>