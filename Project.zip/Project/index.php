<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Book - Home</title>
    <link rel="stylesheet" href="assets/home.css">
</head>
<body>

    <header>
        <div class="container">
            <nav>
                <div class="nav-left"></div>

                <div class="nav-right">
                    <a href="login.php" class="nav-link">Login</a>
                    <a href="register.php" class="nav-link">Register</a>
                </div>
            </nav>

            <h1 class="logo">Contact Book</h1>
        </div>
    </header>

    <main class="container">
        <section class="hero">
            <div class="hero-content">
                <h2>Organize Your World, One Contact at a Time</h2>
                <p>Beautifully manage all your relationships in one secure, intuitive platform.</p>

                <div class="hero-features">
                    <div class="feature">
                        <span class="feature-icon">📱</span>
                        <span>Easy Access</span>
                    </div>
                    <div class="feature">
                        <span class="feature-icon">🔒</span>
                        <span>Secure & Private</span>
                    </div>
                    <div class="feature">
                        <span class="feature-icon">⚡</span>
                        <span>Lightning Fast</span>
                    </div>
                </div>

            </div>
        </section>

        <section class="cta">
            <div class="cta-content">
                <h2>Ready to Organize Your Contacts?</h2>
                <p>Join thousands of users who trust Contact Book</p>
                <div class="cta-buttons">
                    <a href="register.php" class="btn btn-primary">Get Started Free</a>
                    <a href="login.php" class="btn btn-secondary">Sign In</a>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Contact Book - Making connections meaningful</p>
        </div>
    </footer>

</body>
</html>
