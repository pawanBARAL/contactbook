<?php
session_start();
echo "<h3>Logged-in User ID:</h3>";
echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'Not logged in';
?>
