<?php
// test_db.php - Test database connection
echo "<h2>Database Connection Test</h2>";

// Test different connection settings
$configs = [
    ['localhost', 'root', ''],
    ['127.0.0.1', 'root', ''],
    ['localhost', 'root', 'root'],
    ['127.0.0.1', 'root', 'root'],
];

foreach ($configs as $config) {
    list($host, $user, $pass) = $config;
    
    echo "<h3>Trying: host=$host, user=$user</h3>";
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=contact_book;charset=utf8mb4", $user, $pass);
        echo "<p style='color: green;'>✅ SUCCESS: Connected to database!</p>";
        
        // Test if tables exist
        $tables = $pdo->query("SHOW TABLES")->fetchAll();
        echo "<p>Tables found: " . count($tables) . "</p>";
        foreach ($tables as $table) {
            echo "<li>" . $table[0] . "</li>";
        }
        
        break;
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ FAILED: " . $e->getMessage() . "</p>";
    }
}

// Check if MySQL is running
echo "<h3>System Check</h3>";
echo "<p>PHP Version: " . phpversion() . "</p>";

// Check if MySQL extension is loaded
if (extension_loaded('pdo_mysql')) {
    echo "<p style='color: green;'>✅ PDO MySQL extension is loaded</p>";
} else {
    echo "<p style='color: red;'>❌ PDO MySQL extension is NOT loaded</p>";
}
?>