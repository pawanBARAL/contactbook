<?php
require 'config.php';
require_login();

// Get contact ID
$contact_id = $_GET['id'] ?? null;
if (!$contact_id) {
    header("Location: favourites.php");
    exit;
}

$error = "";

// --------------------------------------------------
// STEP 1: Form submitted → CHECK ANSWER ONLY
// --------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $userAnswer = strtolower(trim($_POST['answer']));

    if (isset($_SESSION['answer']) && $userAnswer == $_SESSION['answer']) {

        // Correct answer → remove from favourites
        $stmt = $pdo->prepare("
            UPDATE contacts
            SET is_favourite = 0
            WHERE id = ? AND user_id = ?
        ");
        $stmt->execute([$contact_id, $_SESSION['user_id']]);

        // Clear stored question + answer
        unset($_SESSION['answer']);
        unset($_SESSION['question']);

        header("Location: favourites.php?removed=1");
        exit;

    } else {
        // Wrong answer → keep SAME question
        $error = "Incorrect answer. Try again.";
        $question = $_SESSION['question']; 
    }
}


// --------------------------------------------------
// STEP 2: First time loading the page → GENERATE NEW QUESTION
// --------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    $questionType = rand(1, 4); // random question type

    switch ($questionType) {

        case 1: // Addition
            $a = rand(1, 10);
            $b = rand(1, 10);
            $_SESSION['answer'] = $a + $b;
            $_SESSION['question'] = "$a + $b = ?";
            break;

        case 2: // Subtraction
            $a = rand(5, 15);
            $b = rand(1, 5);
            $_SESSION['answer'] = $a - $b;
            $_SESSION['question'] = "$a - $b = ?";
            break;

        case 3: // Multiplication
            $a = rand(1, 5);
            $b = rand(1, 5);
            $_SESSION['answer'] = $a * $b;
            $_SESSION['question'] = "$a × $b = ?";
            break;

        case 4: // Logic question
            $logicQuestions = [
                ["What is the first letter of 'CAT'?", "c"],
                ["How many letters are in 'DOG'?", "3"],
                ["What color is the sky on a clear day?", "blue"],
                ["What is the last letter of 'APPLE'?", "e"]
            ];

            $pick = $logicQuestions[array_rand($logicQuestions)];
            $_SESSION['answer'] = strtolower($pick[1]);
            $_SESSION['question'] = $pick[0];
            break;
    }

    $question = $_SESSION['question']; // send to HTML
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Validation Required</title>

    <style>
        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background: linear-gradient(135deg, #8b5cf6, #5d6df7);
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .box {
            width: 400px;
            background: #fff;
            padding: 30px;
            border-radius: 14px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.18);
            animation: fadeIn 0.5s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 12px;
            font-size: 24px;
            font-weight: 700;
        }

        .question {
            background: #eef0ff;
            padding: 14px;
            border-radius: 10px;
            border-left: 5px solid #6b6bff;
            margin-bottom: 20px;
            font-size: 16px;
            font-weight: 500;
        }

        .error {
            background: #ffe1e1;
            padding: 12px;
            border-left: 5px solid #ff4b4b;
            border-radius: 10px;
            margin-bottom: 15px;
            color: #a60000;
            font-weight: 500;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            border-radius: 10px;
            border: 1px solid #ccc;
            font-size: 15px;
            background: #fafafa;
            transition: .2s;
        }

        input:focus {
            border-color: #6b6bff;
            background: #fff;
            box-shadow: 0 0 6px rgba(107, 107, 255, 0.4);
            outline: none;
        }

        .btn {
            width: 100%;
            padding: 13px;
            background: linear-gradient(135deg, #6b6bff, #8f67f7);
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            font-weight: 600;
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(90, 90, 255, 0.3);
        }
    </style>

</head>

<body>

    <div class="box">

        <h2>Validation Required</h2>

        <?php if (!empty($error)): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="question">
            To remove this favourite, answer the question below:
            <br><br>
            <strong><?= htmlspecialchars($question) ?></strong>
        </div>

        <form method="POST">
            <input type="text" name="answer" placeholder="Enter your answer..." required>
            <button type="submit" class="btn">Verify & Remove</button>
        </form>

    </div>

</body>

</html>