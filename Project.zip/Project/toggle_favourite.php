<?php
require 'config.php';
require_login();

// Get contact ID from URL
$id = $_GET['id'];

// Check existing favourite status for this contact (and verify ownership)
$stmt = $pdo->prepare("SELECT is_favourite FROM contacts WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $_SESSION['user_id']]);
$contact = $stmt->fetch();

if (!$contact) {
    // Contact doesn't exist or doesn't belong to the user
    exit("Contact not found");
}

// Toggle favourite status: if 1 → set 0, if 0 → set 1
$newValue = $contact['is_favourite'] == 1 ? 0 : 1;

// Update the contact with new favourite value
$stmt = $pdo->prepare("UPDATE contacts SET is_favourite = ? WHERE id = ? AND user_id = ?");
$stmt->execute([$newValue, $id, $_SESSION['user_id']]);

// Redirect back to the previous page
header("Location: " . $_SERVER['HTTP_REFERER']);
exit;