<?php
require 'config.php';
require_login();

if (isset($_GET['id'])) {
    $contact_id = (int)$_GET['id'];
    
    // Restore contact by setting deleted_at to NULL
    $stmt = $pdo->prepare('UPDATE contacts SET deleted_at = NULL WHERE id = ? AND user_id = ?');
    $stmt->execute([$contact_id, $_SESSION['user_id']]);
    
    header('Location: trash.php?restored=1');
    exit;
}

header('Location: trash.php');
exit;
?>