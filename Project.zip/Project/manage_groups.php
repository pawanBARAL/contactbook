<?php
// -------------------------------------------------------------------
// manage_groups.php
// Page for creating, editing, listing, searching, sorting and deleting
// "categories" (called groups in the database) for the logged-in user.
// -------------------------------------------------------------------

require 'config.php';   // sets up $pdo (database) and session
require 'header.php';   // common header / navigation / HTML <head> etc.
require_login();        // custom function: redirects if user is not logged in

// This array will hold validation / logic error messages for the form.
$errors = [];

// When editing or after a failed POST, this will hold the current category data.
$editGroup = null;


// ===================================================================
// 1. DELETE CATEGORY (?delete=ID)
// ===================================================================
//
// If the URL has something like: manage_groups.php?delete=5
// we interpret that as a request to delete the category with id = 5
// BUT only if it belongs to the currently logged-in user.
// After handling, we always redirect back to this page to avoid
// accidental resubmissions and to keep the URL clean.
// ===================================================================
if (isset($_GET['delete'])) {
    // Always cast incoming ID to int to prevent injection / weird types
    $deleteId = (int)$_GET['delete'];

    if ($deleteId > 0) {
        // Delete row only if it belongs to the logged-in user
        $stmt = $pdo->prepare("DELETE FROM groups WHERE id = ? AND user_id = ?");
        $stmt->execute([$deleteId, $_SESSION['user_id']]);
        // If the id doesn't belong to this user, the delete just affects 0 rows.
    }

    // Redirect back to the main manage groups page after delete
    header("Location: manage_groups.php");
    exit;
}


// ===================================================================
// 2. CREATE / UPDATE CATEGORY (POST)
// ===================================================================
//
// This block runs when the user submits the form (Add or Update).
// We:
//   - Collect form data
//   - Validate it
//   - Check uniqueness of name per user
//   - If everything is fine, insert or update in DB
//   - If there are errors, we don't save and we keep values in $editGroup
// ===================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get the name from POST, trimming whitespace. Use null coalescing in case 'name' isn't set.
    $name = trim($_POST['name'] ?? '');

    // If 'id' is present and not empty, this is an update, otherwise it's a new category.
    $id = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;

    // Checkbox returns something only if checked.
    // So we treat "isset" as 1 (true) and not set as 0 (false).
    $is_favorite = isset($_POST['is_favorite']) ? 1 : 0;

    // Status comes from select dropdown. If it's missing, default to 'active'.
    $status = $_POST['status'] ?? 'active';


    // ----------------------
    // 2.1 VALIDATION
    // ----------------------

    // Rule 1: Name cannot be empty
    if ($name === '') {
        $errors[] = 'Category name cannot be empty.';
    }

    // Rule 2: Name cannot be longer than 100 characters
    if ($name !== '' && mb_strlen($name) > 100) {
        $errors[] = 'Category name cannot be longer than 100 characters.';
    }

    // Rule 3: Status must be either 'active' or 'archived'.
    // If an invalid value is submitted (e.g. via tampered request),
    // we fall back to 'active'.
    $allowedStatuses = ['active', 'archived'];
    if (!in_array($status, $allowedStatuses, true)) {
        $status = 'active';
    }


    // ----------------------
    // 2.2 UNIQUE NAME PER USER
    // ----------------------
    //
    // Only check uniqueness if:
    //   - name is not empty
    //   - we don't already have validation errors
    //
    // Rule: a user cannot have two categories with the same name.
    // But different users can have the same category name.
    if ($name !== '' && empty($errors)) {

        if ($id) {
            // EDIT case: exclude this current record's ID when checking
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM groups 
                 WHERE user_id = ? AND name = ? AND id != ?"
            );
            $stmt->execute([$_SESSION['user_id'], $name, $id]);
        } else {
            // CREATE case: any record of same user and same name counts as duplicate
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM groups 
                 WHERE user_id = ? AND name = ?"
            );
            $stmt->execute([$_SESSION['user_id'], $name]);
        }

        // If the count is > 0 then this user already has a category with this name
        if ((int)$stmt->fetchColumn() > 0) {
            $errors[] = 'You already have a category with this name.';
        }
    }


    // ----------------------
    // 2.3 SAVE TO DATABASE
    // ----------------------
    //
    // Only save if there are NO errors.
    // If there are errors, we do not insert or update.
    // ----------------------
    if (empty($errors)) {

        if ($id) {
            // UPDATE existing category
            $stmt = $pdo->prepare(
                "UPDATE groups 
                 SET name = ?, is_favorite = ?, status = ?
                 WHERE id = ? AND user_id = ?"
            );
            $stmt->execute([$name, $is_favorite, $status, $id, $_SESSION['user_id']]);

        } else {
            // INSERT new category
            $stmt = $pdo->prepare(
                "INSERT INTO groups (user_id, name, is_favorite, status) 
                 VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([$_SESSION['user_id'], $name, $is_favorite, $status]);
        }

        // After successful save, redirect to avoid re-POSTing on refresh
        header("Location: manage_groups.php");
        exit;

    } else {
        // If there are validation errors:
        // - Do NOT redirect
        // - Store the posted values in $editGroup so the form is repopulated
        $editGroup = [
            'id'          => $id,
            'name'        => $name,
            'is_favorite' => $is_favorite,
            'status'      => $status,
        ];
    }
}


// ===================================================================
// 3. LOAD CATEGORY FOR EDIT (?edit=ID)
// ===================================================================
//
// When the user clicks the "Edit" button on a category in the list,
// they go to: manage_groups.php?edit=ID
// We then fetch the category from DB (only if it belongs to the user)
// and store it in $editGroup, so the form is pre-filled.
// ===================================================================
if ($editGroup === null && isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];

    if ($editId > 0) {
        $stmt = $pdo->prepare(
            "SELECT * FROM groups 
             WHERE id = ? AND user_id = ?"
        );
        $stmt->execute([$editId, $_SESSION['user_id']]);

        // If the record exists and belongs to this user, we get it as an array.
        $editGroup = $stmt->fetch();
    }
}


// ===================================================================
// 4. SEARCH + SORT SETUP
// ===================================================================
//
// This handles the search box and the sort dropdown.
//   - q = search term typed by the user
//   - sort = one of 'name_asc', 'name_desc', 'favorite', 'newest', 'oldest'
// We build an ORDER BY clause based on the chosen sort.
// ===================================================================
$q    = trim($_GET['q'] ?? '');      // search term (can be empty)
$sort = $_GET['sort'] ?? 'name_asc'; // default sort

switch ($sort) {
    case 'name_desc':
        $orderBy = 'name DESC';
        break;
    case 'newest':
        // higher id = newer (assuming auto-increment id)
        $orderBy = 'id DESC';
        break;
    case 'oldest':
        $orderBy = 'id ASC';
        break;
    case 'favorite':
        // favorites first, then by name ascending
        $orderBy = 'is_favorite DESC, name ASC';
        break;
    case 'name_asc':
    default:
        $orderBy = 'name ASC';
        $sort = 'name_asc';
        break;
}


// ===================================================================
// 5. FETCH ALL CATEGORIES FOR USER (with optional search)
// ===================================================================
//
// We always filter by user_id, so each user only sees their own categories.
// If a search term ($q) is provided, we also filter by name LIKE %q%.
// ===================================================================
if ($q !== '') {
    $stmt = $pdo->prepare(
        "SELECT * FROM groups 
         WHERE user_id = ? 
           AND name LIKE ?
         ORDER BY $orderBy"
    );
    $stmt->execute([$_SESSION['user_id'], '%' . $q . '%']);
} else {
    $stmt = $pdo->prepare(
        "SELECT * FROM groups 
         WHERE user_id = ? 
         ORDER BY $orderBy"
    );
    $stmt->execute([$_SESSION['user_id']]);
}

// Fetch all categories for the current user (after filtering/sorting)
$groups = $stmt->fetchAll();

// $isEditing is true when we are editing an existing category
$isEditing = $editGroup && isset($editGroup['id']);

// These help preselect dropdown and checkbox in the form
$currentStatus   = $editGroup['status'] ?? 'active';
$currentFavorite = !empty($editGroup['is_favorite']);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories - Contact Book</title>
    <link rel="stylesheet" href="assets/style.css">

    <style>
        /* ------------------------------
           CSS STYLES FOR PAGE LAYOUT
           ------------------------------ */

        :root {
            --primary: #4a6cf7;
            --primary-light: #eef2ff;
            --secondary: #6c757d;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --border: #dee2e6;
            --shadow: rgba(0, 0, 0, 0.1);
            --archived-bg: #f3f3f3;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--dark);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }

        .container {
            max-width: 800px;
            margin: 80px auto 0;
        }

        .content {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px var(--shadow);
            margin-bottom: 30px;
        }

        h2 {
            color: var(--primary);
            font-weight: 700;
            font-size: 28px;
            text-align: center;
            margin: 0 0 10px;
        }

        .subtitle {
            text-align: center;
            color: var(--secondary);
            margin-bottom: 20px;
            font-size: 14px;
        }

        .add-form {
            background: var(--light);
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            border: 1px solid var(--border);
        }

        /* Error box shown when $errors is not empty */
        .error-message {
            background: #ffe6e6;
            border: 1px solid #ffaaaa;
            color: #b30000;
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .form-group {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: flex-end;
        }

        input[type="text"] {
            flex: 1 1 200px;
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid var(--border);
            font-size: 16px;
        }

        .btn {
            padding: 12px 20px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
        }

        .btn-secondary {
            padding: 10px 16px;
            background: var(--secondary);
            color: white;
            border-radius: 8px;
            font-size: 14px;
            text-decoration: none;
        }

        .categories-list {
            margin-top: 30px;
        }

        .category-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: white;
            border: 1px solid var(--border);
            border-radius: 8px;
            margin-bottom: 12px;
        }

        /* Slightly greyed-out style for archived categories */
        .category-item.archived {
            background: var(--archived-bg);
            opacity: 0.9;
        }

        .category-main {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .favorite-icon {
            font-size: 18px;
        }

        .favorite-icon.active {
            color: #f5c518; /* gold star */
        }

        .category-name {
            font-weight: 600;
            font-size: 16px;
        }

        .status-badge {
            padding: 2px 8px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-badge.active {
            background: #e0f7e9;
            color: #137333;
        }

        .status-badge.archived {
            background: #f1f3f4;
            color: #5f6368;
        }

        .category-actions {
            display: flex;
            gap: 8px;
        }

        .edit-btn,
        .delete-btn {
            border-radius: 6px;
            padding: 8px 15px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
        }

        .edit-btn {
            background: var(--primary-light);
            color: var(--primary);
        }

        .delete-btn {
            background: var(--danger);
            color: #fff;
        }

        .empty-state {
            padding: 40px;
            text-align: center;
            color: var(--secondary);
            background: var(--light);
            border-radius: 10px;
            border: 1px dashed var(--border);
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
        }

        /* Search & Sort bar above the list */
        .search-sort-bar {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .search-sort-bar input[type="text"] {
            flex: 1 1 180px;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid var(--border);
        }

        .search-sort-bar select {
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid var(--border);
        }

        /* Favorite toggle checkbox label in form */
        .favorite-toggle {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 14px;
            color: var(--secondary);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            <h2>Manage Categories</h2>

            <!-- Subtitle changes depending on context: editing, searching, or default -->
            <div class="subtitle">
                <?php if ($isEditing): ?>
                    Editing category
                <?php elseif ($q !== ''): ?>
                    Showing results for "<?= htmlspecialchars($q) ?>"
                <?php else: ?>
                    Create, edit & organize your categories.
                <?php endif; ?>
            </div>

            <!-- ============= FORM AREA ============= -->
            <div class="add-form">

                <!-- If there are any validation errors, show them here -->
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <strong>Please fix the following:</strong>
                        <ul>
                            <?php foreach ($errors as $e): ?>
                                <li><?= htmlspecialchars($e) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Main form for adding / editing categories -->
                <form method="post">
                    <div class="form-group">

                        <!-- Hidden field for ID: if set, we are editing; if empty, adding new -->
                        <input type="hidden" name="id"
                               value="<?= $isEditing ? (int)$editGroup['id'] : '' ?>">

                        <!-- Category name text field -->
                        <input type="text"
                               name="name"
                               placeholder="Enter category name"
                               required
                               value="<?= htmlspecialchars($editGroup['name'] ?? '') ?>">

                        <!-- Favorite checkbox -->
                        <label class="favorite-toggle">
                            <input type="checkbox" name="is_favorite"
                                   <?= $currentFavorite ? 'checked' : '' ?>>
                            ⭐ Favorite
                        </label>

                        <!-- Status dropdown: Active / Archived -->
                        <select name="status">
                            <option value="active"   <?= $currentStatus === 'active'   ? 'selected' : '' ?>>Active</option>
                            <option value="archived" <?= $currentStatus === 'archived' ? 'selected' : '' ?>>Archived</option>
                        </select>

                        <!-- Submit button: text changes depending on edit/add mode -->
                        <button type="submit" class="btn">
                            <?= $isEditing ? '💾 Update' : '➕ Add' ?>
                        </button>

                        <!-- Cancel button only shown when we are editing -->
                        <?php if ($isEditing): ?>
                            <a href="manage_groups.php" class="btn-secondary">Cancel</a>
                        <?php endif; ?>

                    </div>
                </form>

            </div>

            <!-- ============= LIST AREA ============= -->
            <div class="categories-list">

                <!-- Search and Sort form (GET method, because it controls the view state) -->
                <form method="get" class="search-sort-bar">
                    <input type="text" name="q"
                           placeholder="Search..."
                           value="<?= htmlspecialchars($q) ?>">

                    <select name="sort">
                        <option value="name_asc"  <?= $sort === 'name_asc'  ? 'selected' : '' ?>>Name A–Z</option>
                        <option value="name_desc" <?= $sort === 'name_desc' ? 'selected' : '' ?>>Name Z–A</option>
                        <option value="favorite"  <?= $sort === 'favorite'  ? 'selected' : '' ?>>Favorites first</option>
                        <option value="newest"    <?= $sort === 'newest'    ? 'selected' : '' ?>>Newest first</option>
                        <option value="oldest"    <?= $sort === 'oldest'    ? 'selected' : '' ?>>Oldest first</option>
                    </select>

                    <button type="submit" class="btn-secondary">Search</button>

                    <!-- Reset link appears only if there is a search term or non-default sort -->
                    <?php if ($q !== '' || $sort !== 'name_asc'): ?>
                        <a href="manage_groups.php" class="btn-secondary">Reset</a>
                    <?php endif; ?>
                </form>

                <!-- If user has no categories (or no matches), show empty state -->
                <?php if (empty($groups)): ?>
                    <div class="empty-state">
                        No categories found.
                    </div>
                <?php else: ?>

                    <!-- Loop through each category and display it in the list -->
                    <?php foreach ($groups as $g): ?>
                        <?php
                        // Determine if this group is favorite and its status
                        $isFav  = !empty($g['is_favorite']);
                        $status = $g['status'];
                        ?>
                        <div class="category-item <?= $status === 'archived' ? 'archived' : '' ?>">

                            <div class="category-main">
                                <!-- Star icon: filled if favorite, hollow otherwise -->
                                <span class="favorite-icon <?= $isFav ? 'active' : '' ?>">
                                    <?= $isFav ? '★' : '☆' ?>
                                </span>

                                <!-- Category name (escaped for safety) -->
                                <span class="category-name">
                                    <?= htmlspecialchars($g['name']) ?>
                                </span>

                                <!-- Status badge: Active or Archived -->
                                <span class="status-badge <?= $status ?>">
                                    <?= ucfirst($status) ?>
                                </span>
                            </div>

                            <div class="category-actions">
                                <!-- Edit link: goes to ?edit=ID which loads edit data above -->
                                <a href="?edit=<?= (int)$g['id'] ?>" class="edit-btn">✏️ Edit</a>

                                <!-- Delete link: goes to ?delete=ID, with JS confirm dialog -->
                                <a href="?delete=<?= (int)$g['id'] ?>"
                                   class="delete-btn"
                                   onclick="return confirm('Delete this category?')">
                                   🗑️ Delete
                                </a>
                            </div>

                        </div>
                    <?php endforeach; ?>

                <?php endif; ?>
            </div>

            <!-- Link back to contacts page -->
            <a href="view_contacts.php" class="back-link">← Back to Contacts</a>

        </div>
    </div>

</body>
</html>
