<?php
require 'config.php';
require_login();

if (isset($_GET['id'])) {
    $contact_id = (int)$_GET['id'];
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Delete address first (due to foreign key constraint)
        $stmt = $pdo->prepare('DELETE FROM address WHERE contact_id = ?');
        $stmt->execute([$contact_id]);
        
        // Then delete the contact permanently
        $stmt = $pdo->prepare('DELETE FROM contacts WHERE id = ? AND user_id = ?');
        $stmt->execute([$contact_id, $_SESSION['user_id']]);
        
        $pdo->commit();
        header('Location: trash.php?permanently_deleted=1');
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log('Permanent delete failed: ' . $e->getMessage());
        header('Location: trash.php?error=1');
        exit;
    }
}

header('Location: trash.php');
exit;
?>