<?php
require 'config.php';
require 'header.php';
require_login();

// SUCCESS MESSAGE
$success = "";
if (isset($_GET['removed']) && $_GET['removed'] == 1) {
    $success = "Contact removed from favourites successfully.";
}

// Get search keyword
$search = trim($_GET['search'] ?? '');

// Get filter letter (A–Z)
$filterLetter = isset($_GET['filter']) ? strtoupper($_GET['filter']) : "";

// ------------------------------------------------------
// Fetch ALL favourite contacts
// ------------------------------------------------------
$stmt = $pdo->prepare("
    SELECT c.*, a.city
    FROM contacts c
    LEFT JOIN address a ON c.id = a.contact_id
    WHERE c.user_id = ?
      AND c.is_favourite = 1
      AND c.deleted_at IS NULL
    ORDER BY c.name ASC
");
$stmt->execute([$_SESSION['user_id']]);
$allFavourites = $stmt->fetchAll();

// ------------------------------------------------------
// MULTI-WORD SEARCH FILTER
// ------------------------------------------------------
if ($search !== "") {

    $keywords = preg_split('/\s+/', strtolower($search));
    $filtered = [];

    foreach ($allFavourites as $c) {

        $name  = strtolower($c['name']);
        $phone = strtolower($c['phone']);
        $city  = strtolower($c['city']);

        $matchesAll = true;

        foreach ($keywords as $word) {
            if (
                strpos($name, $word) === false &&
                strpos($phone, $word) === false &&
                strpos($city, $word) === false
            ) {
                $matchesAll = false;
                break;
            }
        }

        if ($matchesAll) {
            $filtered[] = $c;
        }
    }

    $favourites = $filtered;

} else {
    $favourites = $allFavourites;
}

// ------------------------------------------------------
// A–Z FILTER LOGIC (AFTER SEARCH)
// ------------------------------------------------------
if ($filterLetter !== "" && strlen($filterLetter) == 1) {

    $favourites = array_filter($favourites, function($c) use ($filterLetter) {
        return strtoupper(substr($c['name'], 0, 1)) === $filterLetter;
    });
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Favourite Contacts</title>
    <link rel="stylesheet" href="assets/favourites.css">

    <style>
        .small-phone {
            font-size: 13px;
            color: #555;
        }

        .success-msg {
            background: #e6ffed;
            padding: 12px 18px;
            border-left: 5px solid #28a745;
            color: #155724;
            border-radius: 8px;
            font-size: 15px;
            margin-bottom: 18px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            animation: slideDown 0.4s ease;
        }

        @keyframes slideDown {
            from { opacity:0; transform: translateY(-10px); }
            to   { opacity:1; transform: translateY(0); }
        }

        /* FILTER BOX CONTAINER */
.filter-box {
    background: #ffffff;
    padding: 15px;
    border-radius: 12px;
    box-shadow: 0px 4px 12px rgba(0,0,0,0.08);
    margin: 15px auto 20px;
    width: 95%;
    max-width: 700px;
}

/* TITLE */
.filter-title {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 8px;
    color: #333;
}

/* BUTTON AREA */
.filter-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    justify-content: center;
}

/* LETTER BUTTONS */
.filter-btn {
    padding: 6px 10px;
    background: #edf0ff;
    color: #4a4aff;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    transition: 0.2s ease;
}

.filter-btn:hover {
    background: #4a4aff;
    color: #fff;
}

/* ACTIVE FILTER BUTTON */
.filter-btn.active {
    background: #4a4aff;
    color: #fff;
    box-shadow: 0px 2px 8px rgba(74, 74, 255, 0.4);
}

/* ALL BUTTON */
.filter-btn.all {
    background: #ffecec;
    color: #cc0000;
}

.filter-btn.all:hover {
    background: #ffbaba;
    color: #900;
}

.listing-title {
    font-size: 20px;
    font-weight: 700;
    color: #5d6df7; /* soft purple */
    background: #eef0ff; /* very light purple */
    padding: 10px 14px;
    border-radius: 8px;
    width: fit-content;
    margin: 25px 0 10px;
}


    </style>

    <script>
        function resetSearch(input) {
            if (input.value.trim() === "") {
                window.location.href = "favourites.php";
            }
        }
    </script>
</head>

<body>

<div class="fav-container">

    <h2>⭐ Favourite Contacts</h2>

    <!-- A–Z FILTER BOX -->
<div class="filter-box">
    <div class="filter-title">Filter by Letter:</div>

    <div class="filter-buttons">
        <?php foreach (range('A', 'Z') as $letter): ?>
            <a href="favourites.php?filter=<?= $letter ?>"
               class="filter-btn <?= ($filterLetter === $letter ? 'active' : '') ?>">
                <?= $letter ?>
            </a>
        <?php endforeach; ?>

        <a href="favourites.php" class="filter-btn all">ALL</a>
    </div>
</div>


    <!-- SUCCESS MESSAGE -->
    <?php if (!empty($success)): ?>
        <div class="success-msg">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <!-- SEARCH BAR -->
    <form method="get" class="search-bar">
        <input type="text" 
               name="search" 
               placeholder="Search favourite (supports multiple words)..."
               onkeyup="resetSearch(this)"
               value="<?= htmlspecialchars($search) ?>">

        <button type="submit">Search</button>
    </form>

    <!-- IF NO RESULTS -->
    <?php if (empty($favourites)): ?>
        <p style="text-align:center; color:#666; font-size:16px; padding:20px;">
            No favourite contacts found.
        </p>
    <?php else: ?>

    <!-- CONTACT LIST TABLE -->

     
    <table>
        <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>City</th>
            <th>Actions</th>
        </tr>

        <?php foreach ($favourites as $fav): ?>
        <tr>
            <td>
                <strong><?= htmlspecialchars($fav['name']) ?></strong><br>
                <span class="small-phone">📞 <?= htmlspecialchars($fav['phone']) ?></span>
            </td>

            <td><?= htmlspecialchars($fav['phone']) ?></td>
            <td><?= htmlspecialchars($fav['email']) ?></td>
            <td><?= htmlspecialchars($fav['city']) ?></td>

            <td class="actions">
                <a href="favourites_login.php?contact_id=<?= $fav['id'] ?>">Edit</a>
                <a href="favourites_validation.php?id=<?= $fav['id'] ?>" class="remove">Remove</a>
            </td>
        </tr>
        <?php endforeach; ?>

    </table>

    <?php endif; ?>

</div>

</body>
</html>