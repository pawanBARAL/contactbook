<?php
require 'config.php';
require 'admin_header.php';
require_admin();

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? 'user';
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $security_question = trim($_POST['security_question'] ?? '');
    $security_answer = trim($_POST['security_answer'] ?? '');

    // Validation
    if (empty($name) || empty($email) || empty($password)) {
        $errors[] = 'Name, email, and password are required.';
    }

    if (!validate_email($email)) {
        $errors[] = 'Invalid email format.';
    }

    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    }

    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match.';
    }

    if (strlen($name) < 2 || strlen($name) > 100) {
        $errors[] = 'Name must be between 2 and 100 characters.';
    }

    // Validate security data if provided
    if (!empty($security_question) || !empty($security_answer)) {
        $security_errors = validate_security_data($security_question, $security_answer);
        if (!empty($security_errors)) {
            $errors = array_merge($errors, $security_errors);
        }
    }

    // Check if email already exists
    if (empty($errors)) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'An account with this email already exists.';
        }
    }

    // Create user if no errors
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $hashed_answer = !empty($security_answer) ? password_hash(strtolower(trim($security_answer)), PASSWORD_DEFAULT) : null;

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role, is_active, security_question, security_answer) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([$name, $email, $hash, $role, $is_active, $security_question ?: null, $hashed_answer]);
            
            $user_id = $pdo->lastInsertId();

            // Automatically add default categories for the new user
            $defaultGroups = ['Family', 'Friends', 'Business', 'Work'];
            $groupStmt = $pdo->prepare('INSERT INTO groups (user_id, name) VALUES (?, ?)');
            foreach ($defaultGroups as $groupName) {
                $groupStmt->execute([$user_id, $groupName]);
            }

            $pdo->commit();
            
            // Log the action
            log_admin_action('user_create', "Created new $role: $email (ID: $user_id)");
            
            $success = true;
            
            // Reset form on success
            $name = $email = $security_question = $security_answer = '';
            $role = 'user';
            $is_active = 1;
            
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log('User creation failed: ' . $e->getMessage());
            $errors[] = 'Failed to create user. Please try again.';
        }
    }
}

// Get security questions
$security_questions = get_security_questions();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User - Admin Panel</title>
    <style>
        :root {
            --primary: #5d6df7;
            --primary-dark: #4a5bd9;
            --primary-light: #e8edff;
            --secondary: #6b7280;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --light: #f8fafc;
            --dark: #1f2937;
            --border: #e5e7eb;
            --shadow: rgba(0, 0, 0, 0.08);
        }

        .admin-container {
            max-width: 800px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .page-header {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
            margin-bottom: 30px;
        }

        .page-header h1 {
            color: var(--darker);
            margin: 0 0 10px 0;
            font-size: 28px;
        }

        .page-header p {
            color: var(--secondary);
            margin: 0;
        }

        .form-card {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
        }

        .form-section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border);
        }

        .form-section:last-child {
            border-bottom: none;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--darker);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
        }

        .required::after {
            content: " *";
            color: var(--danger);
        }

        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(93, 109, 247, 0.2);
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox-group input {
            width: auto;
            transform: scale(1.2);
        }

        .radio-group {
            display: flex;
            gap: 20px;
            margin-top: 8px;
        }

        .radio-option {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .radio-option input {
            width: auto;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(93, 109, 247, 0.3);
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .error {
            background: #fef2f2;
            color: var(--danger);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #fecaca;
        }

        .success {
            background: #f0fdf4;
            color: var(--success);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #bbf7d0;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid var(--border);
        }

        .security-note {
            background: var(--primary-light);
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid var(--primary);
            margin-top: 10px;
            font-size: 14px;
            color: var(--dark);
        }

        .optional {
            color: var(--secondary);
            font-weight: normal;
        }

        .password-strength {
            margin-top: 8px;
            font-size: 14px;
            font-weight: 500;
        }

        .strength-weak { color: var(--danger); }
        .strength-medium { color: var(--warning); }
        .strength-strong { color: var(--success); }

        .progress-bar {
            height: 4px;
            background: var(--border);
            border-radius: 2px;
            margin-top: 5px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            transition: all 0.3s ease;
        }

        @media (max-width: 768px) {
            .form-actions {
                flex-direction: column;
            }
            
            .radio-group {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>

<main class="admin-container">
    <!-- Page Header -->
    <div class="page-header">
        <h1>Add New User</h1>
        <p>Create a new user account in the system</p>
    </div>

    <!-- Success Message -->
    <?php if ($success): ?>
        <div class="success">
            ✅ User created successfully! 
            <a href="admin_users.php" style="color: var(--success); font-weight: 600;">View all users</a> or 
            <a href="admin_users_add.php" style="color: var(--success); font-weight: 600;">add another user</a>.
        </div>
    <?php endif; ?>

    <!-- Error Messages -->
    <?php if (!empty($errors)): ?>
        <div class="error">
            <strong>❌ The following errors occurred:</strong><br>
            <?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?>
        </div>
    <?php endif; ?>

    <!-- User Creation Form -->
    <div class="form-card">
        <form method="post" action="admin_users_add.php" id="userForm">
            
            <!-- Basic Information Section -->
            <div class="form-section">
                <div class="section-title">
                    <span>👤</span>
                    Basic Information
                </div>

                <div class="form-group">
                    <label for="name" class="required">Full Name</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($name ?? '') ?>" 
                           placeholder="Enter user's full name" required minlength="2" maxlength="100">
                </div>

                <div class="form-group">
                    <label for="email" class="required">Email Address</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($email ?? '') ?>" 
                           placeholder="Enter user's email address" required>
                </div>
            </div>

            <!-- Account Settings Section -->
            <div class="form-section">
                <div class="section-title">
                    <span>⚙️</span>
                    Account Settings
                </div>

                <div class="form-group">
                    <label class="required">User Role</label>
                    <div class="radio-group">
                        <label class="radio-option">
                            <input type="radio" name="role" value="user" <?= ($role ?? 'user') === 'user' ? 'checked' : '' ?>>
                            Regular User
                        </label>
                        <label class="radio-option">
                            <input type="radio" name="role" value="admin" <?= ($role ?? '') === 'admin' ? 'checked' : '' ?>>
                            Administrator
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <label class="checkbox-group">
                        <input type="checkbox" name="is_active" value="1" <?= ($is_active ?? 1) ? 'checked' : '' ?>>
                        Active Account (User can login)
                    </label>
                </div>
            </div>

            <!-- Security Section -->
            <div class="form-section">
                <div class="section-title">
                    <span>🔒</span>
                    Security Settings
                </div>

                <div class="form-group">
                    <label for="password" class="required">Password</label>
                    <input type="password" id="password" name="password" 
                           placeholder="Create a secure password" required minlength="6"
                           oninput="checkPasswordStrength(this.value)">
                    <div class="progress-bar">
                        <div class="progress-fill" id="password-progress"></div>
                    </div>
                    <div id="password-strength" class="password-strength"></div>
                </div>

                <div class="form-group">
                    <label for="confirm_password" class="required">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" 
                           placeholder="Confirm the password" required minlength="6"
                           oninput="checkPasswordMatch()">
                    <div id="password-match" class="password-strength"></div>
                </div>

                <div class="form-group">
                    <label for="security_question">Security Question <span class="optional">(Optional)</span></label>
                    <select id="security_question" name="security_question">
                        <option value="">Select a security question (optional)...</option>
                        <?php foreach ($security_questions as $question): ?>
                            <option value="<?= htmlspecialchars($question) ?>" 
                                <?= (isset($security_question) && $security_question === $question) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($question) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="security_answer">Security Answer <span class="optional">(Optional)</span></label>
                    <input type="text" id="security_answer" name="security_answer" 
                           value="<?= htmlspecialchars($security_answer ?? '') ?>" 
                           placeholder="Enter security answer" minlength="2" maxlength="100">
                    <div class="security-note">
                        ⚠️ This will be used for password recovery. If provided, both question and answer are required.
                        Answer is case-insensitive and stored securely.
                    </div>
                </div>
            </div>

            <!-- Form Actions -->
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <span>➕</span>
                    Create User
                </button>
                <a href="admin_users.php" class="btn btn-secondary">
                    <span>←</span>
                    Back to Users
                </a>
                <button type="reset" class="btn btn-secondary" onclick="resetForm()">
                    <span>🔄</span>
                    Reset Form
                </button>
            </div>
        </form>
    </div>
</main>

<script>
    function checkPasswordStrength(password) {
        const strengthElement = document.getElementById('password-strength');
        const progressElement = document.getElementById('password-progress');
        let strength = 0;
        let strengthText = '';
        let strengthClass = '';
        
        if (password.length === 0) {
            strengthElement.innerHTML = '';
            progressElement.style.width = '0%';
            progressElement.style.background = '';
            return;
        }
        
        // Calculate strength
        if (password.length >= 6) strength += 25;
        if (password.length >= 8) strength += 15;
        if (/[A-Z]/.test(password)) strength += 20;
        if (/[a-z]/.test(password)) strength += 20;
        if (/\d/.test(password)) strength += 20;
        if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength += 20;
        
        // Determine strength level
        if (strength < 40) {
            strengthText = 'Weak';
            strengthClass = 'strength-weak';
            progressElement.style.background = '#ef4444';
        } else if (strength < 70) {
            strengthText = 'Medium';
            strengthClass = 'strength-medium';
            progressElement.style.background = '#f59e0b';
        } else {
            strengthText = 'Strong';
            strengthClass = 'strength-strong';
            progressElement.style.background = '#10b981';
        }
        
        progressElement.style.width = Math.min(strength, 100) + '%';
        strengthElement.innerHTML = `<span class="${strengthClass}">Password Strength: ${strengthText}</span>`;
    }
    
    function checkPasswordMatch() {
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        const matchElement = document.getElementById('password-match');
        
        if (confirmPassword.length === 0) {
            matchElement.innerHTML = '';
            return;
        }
        
        if (password === confirmPassword) {
            matchElement.innerHTML = '<span class="strength-strong">✅ Passwords match</span>';
        } else {
            matchElement.innerHTML = '<span class="strength-weak">❌ Passwords do not match</span>';
        }
    }
    
    function resetForm() {
        document.getElementById('password-strength').innerHTML = '';
        document.getElementById('password-match').innerHTML = '';
        document.getElementById('password-progress').style.width = '0%';
    }
    
    // Form validation
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('userForm');
        const submitBtn = form.querySelector('button[type="submit"]');
        
        form.addEventListener('input', function() {
            const requiredFields = form.querySelectorAll('input[required], select[required]');
            let allFilled = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    allFilled = false;
                }
            });
            
            // Check password match
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const passwordsMatch = password === confirmPassword && password.length >= 6;
            
            // Check security question/answer consistency
            const securityQuestion = document.getElementById('security_question').value;
            const securityAnswer = document.getElementById('security_answer').value;
            const securityConsistent = (securityQuestion === '' && securityAnswer === '') || 
                                     (securityQuestion !== '' && securityAnswer !== '');
            
            submitBtn.disabled = !allFilled || !passwordsMatch || !securityConsistent;
        });
        
        // Initial check
        form.dispatchEvent(new Event('input'));
    });
</script>

</body>
</html>