<?php
require 'config.php';
require 'header.php'; // MUST BE HERE ONLY ONCE
require_login();

$restored = isset($_GET['restored']);
$permanently_deleted = isset($_GET['permanently_deleted']);

// Fetch deleted contacts
$stmt = $pdo->prepare('SELECT c.*, a.street, a.city, a.state, a.postal_code, g.name AS group_name
                       FROM contacts c
                       LEFT JOIN address a ON c.id = a.contact_id
                       LEFT JOIN groups g ON c.group_id = g.id
                       WHERE c.user_id = ? AND c.deleted_at IS NOT NULL
                       ORDER BY c.deleted_at DESC');
$stmt->execute([$_SESSION['user_id']]);
$deleted_contacts = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Trash - Contact Book</title>

    <!-- Put all CSS inside HEAD -->
    <style>
        :root {
            --primary: #4a6cf7;
            --primary-light: #eef2ff;
            --secondary: #6c757d;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --light: #f8f9fa;
            --dark: #343a40;
            --border: #dee2e6;
            --shadow: rgba(0,0,0,0.1);
        }

        body {
            background: linear-gradient(135deg,#f5f7fa,#e4e8f0);
            font-family: "Segoe UI", Tahoma;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            color: var(--dark);
        }

        .trash-container {
            max-width: 1200px;
            margin: 20px auto 50px;
            padding: 0 20px;
        }

        h2 {
            text-align: center;
            font-size: 32px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 25px;
            padding-bottom: 10px;
            position: relative;
        }

        h2::after {
            content: "";
            position: absolute;
            width: 70px;
            height: 4px;
            background: var(--primary);
            border-radius: 3px;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
        }

        .message {
            padding: 12px;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .empty-trash {
            background: white;
            border-radius: 12px;
            padding: 50px;
            text-align: center;
            color: var(--secondary);
            box-shadow: 0 4px 12px var(--shadow);
        }

        .empty-trash .icon {
            font-size: 60px;
            margin-bottom: 10px;
            opacity: 0.5;
        }

        .contact-grid {
            display: grid;
            gap: 25px;
            grid-template-columns: repeat(auto-fill,minmax(300px,1fr));
        }

        .contact-card {
            background: white;
            padding: 20px;
            border-top: 4px solid var(--warning);
            border-radius: 12px;
            box-shadow: 0 4px 12px var(--shadow);
            transition: 0.3s;
        }

        .contact-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px var(--shadow);
        }

        .contact-card h3 {
            margin: 0 0 12px;
            font-size: 20px;
            font-weight: 700;
            border-bottom: 1px solid var(--border);
            padding-bottom: 10px;
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .actions a,
        .actions button {
            flex: 1;
            padding: 8px;
            border-radius: 6px;
            color: white;
            font-weight: 500;
            border: none;
            cursor: pointer;
        }

        .restore {
            background: var(--success);
        }

        .delete-permanent {
            background: var(--danger);
        }

        .back-link {
            display: inline-block;
            margin-top: 35px;
            background: white;
            padding: 10px 18px;
            border-radius: 6px;
            color: var(--primary);
            font-weight: 500;
            box-shadow: 0 2px 6px var(--shadow);
            text-decoration: none;
        }

        /* Modal */
        .modal { display:none; position:fixed; left:0;top:0;width:100%;height:100%; background:rgba(0,0,0,0.5); }
        .modal-content { background:white; margin:10% auto; max-width:420px; border-radius:12px; overflow:hidden; }
        .modal-header { padding:20px; text-align:center; }
        .modal-body { padding:20px; text-align:center; }
        .modal-footer { padding:20px; display:flex; gap:10px; }
        .modal-btn { flex:1; padding:12px; border-radius:8px; font-weight:600; border:none; cursor:pointer; }
        .cancel { background:var(--light); }
        .confirm { background:var(--danger); color:white; }
    </style>
</head>
<body>

<main class="trash-container">

    <h2>Deleted Contacts</h2>

    <?php if ($restored): ?>
        <div class="message success">✔ Contact restored successfully.</div>
    <?php endif; ?>

    <?php if ($permanently_deleted): ?>
        <div class="message success">🗑 Contact permanently deleted.</div>
    <?php endif; ?>

    <?php if (empty($deleted_contacts)): ?>
        <div class="empty-trash">
            <div class="icon">🗑️</div>
            <h3>Trash is Empty</h3>
            <p>No deleted contacts found.</p>
        </div>
    <?php else: ?>

        <div class="contact-grid">
            <?php foreach ($deleted_contacts as $c): ?>
                <div class="contact-card">
                    <h3><?= htmlspecialchars($c['name']); ?></h3>

                    <p>📞 <?= htmlspecialchars(($c['country_code'] ?? '') . ' ' . ($c['phone'] ?? '—')); ?></p>
                    <p>✉️ <?= htmlspecialchars($c['email'] ?: '—'); ?></p>

                    <div class="actions">
                        <a class="restore" href="restore_contact.php?id=<?= $c['id']; ?>">🔄 Restore</a>

                        <button class="delete-permanent"
                                data-id="<?= $c['id']; ?>"
                                data-name="<?= htmlspecialchars($c['name']); ?>">
                            🗑 Delete Forever
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>

    <a href="view_contacts.php" class="back-link">← Back to Contacts</a>

</main>

<!-- Modal -->
<div id="deleteModal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h3>Permanent Delete</h3></div>

        <div class="modal-body">
            <p>Delete <span id="contactName" style="font-weight:bold;"></span> permanently?</p>
            <p style="color:red;">This action cannot be undone.</p>
        </div>

        <div class="modal-footer">
            <button class="modal-btn cancel">Cancel</button>
            <button class="modal-btn confirm">Delete</button>
        </div>
    </div>
</div>

<script>
    let deleteId = null;

    document.querySelectorAll(".delete-permanent").forEach(btn => {
        btn.addEventListener("click", () => {
            deleteId = btn.dataset.id;
            document.getElementById("contactName").textContent = btn.dataset.name;
            document.getElementById("deleteModal").style.display = "block";
        });
    });

    document.querySelector(".cancel").onclick = () => {
        document.getElementById("deleteModal").style.display = "none";
    };

    document.querySelector(".confirm").onclick = () => {
        window.location.href = "delete_permanent.php?id=" + deleteId;
    };
</script>

</body>
</html>
