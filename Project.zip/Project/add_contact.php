<?php
require 'config.php';      // Load database settings
require 'header.php';      // Load page header
require_login();           // Check if user is logged in

$errors = [];              // Array to store error messages

// Set all variables to empty values
$name = $phone = $email = $street = $city = $state = $postal = $country_code = '';
$group_id = null;

// Get user's *ACTIVE* contact groups for dropdown
$stmt = $pdo->prepare(
    'SELECT id, name 
     FROM groups 
     WHERE user_id = ? 
       AND status = "active"
     ORDER BY is_favorite DESC, name ASC'
);
$stmt->execute([$_SESSION['user_id']]);
$groups = $stmt->fetchAll();

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and clean form data
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $street = trim($_POST['street'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $postal = trim($_POST['postal'] ?? '');
    $group_id = $_POST['group_id'] ?? null;
    $country_code = trim($_POST['country_code'] ?? '');

    // Check required fields
    if ($name === '' || $phone === '') {
        $errors[] = 'Name and phone are required.';
    }

    // Validate email format if provided
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email.';
    }

    // Format country code (keep only numbers and add +)
    if ($country_code !== '') {
        $country_code = '+' . preg_replace('/\D+/', '', $country_code);
    } else {
        $country_code = null;
    }

    // Clean phone number (keep only numbers)
    $phone_digits = preg_replace('/\D+/', '', $phone);

    // Validate phone number
    if ($phone_digits === '') {
        $errors[] = 'Phone number is invalid.';
    } elseif (strlen($phone_digits) < 6 || strlen($phone_digits) > 15) {
        $errors[] = 'Phone number length looks invalid.';
    }

    // Check if selected group belongs to user *AND is active*
    if (!empty($group_id)) {
        $gstmt = $pdo->prepare(
            'SELECT id 
             FROM groups 
             WHERE id = ? 
               AND user_id = ? 
               AND status = "active"'
        );
        $gstmt->execute([(int)$group_id, $_SESSION['user_id']]);
        if (!$gstmt->fetch()) {
            $errors[] = 'Invalid category selected.';
        }
    } else {
        $group_id = null;
    }

    // If no errors, save to database
    if (empty($errors)) {
        $pdo->beginTransaction();  // Start database transaction
        try {
            // Save contact information
            $stmt = $pdo->prepare('INSERT INTO contacts (user_id, name, phone, country_code, email, group_id) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $_SESSION['user_id'],
                $name,
                $phone_digits,
                $country_code,
                $email ?: null,
                $group_id ?: null
            ]);

            // Get the ID of the new contact
            $contact_id = $pdo->lastInsertId();

            // Save address information
            $stmt = $pdo->prepare('INSERT INTO address (contact_id, street, city, state, postal_code) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$contact_id, $street ?: null, $city ?: null, $state ?: null, $postal ?: null]);

            $pdo->commit();  // Save all changes to database
            
            // Go to contacts page with success message
            header('Location: view_contacts.php?added=1');
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();  // Cancel changes if error
            error_log('Add contact failed: ' . $e->getMessage());  // Log error
            $errors[] = 'Failed to add contact. Please try again later.';
        }
    }
}
?>


<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Add Contact - Contact Book</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        /* Color scheme */
        :root {
            --primary: #4a6cf7;
            --primary-light: #eef2ff;
            --secondary: #6c757d;
            --success: #28a745;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --border: #dee2e6;
            --shadow: rgba(0, 0, 0, 0.1);
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--dark);
            line-height: 1.6;
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }
        
        .header {
            background: white;
            box-shadow: 0 2px 10px var(--shadow);
            padding: 15px 0;
            margin-bottom: 30px;
        }
        
        .header .container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        
        .logo {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
            margin: 0;
        }
        
        nav a {
            margin-left: 20px;
            text-decoration: none;
            color: var(--secondary);
            font-weight: 500;
            padding: 8px 12px;
            border-radius: 6px;
            transition: all 0.3s ease;
        }
        
        nav a:hover, nav a.active {
            background: var(--primary-light);
            color: var(--primary);
        }
        
        .container {
            max-width: 700px;
            margin: 0 auto 40px;
            padding: 0 20px;
        }
        
        .box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 15px var(--shadow);
            border: none;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .box:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        h2 {
            margin: 0 0 20px 0;
            color: var(--primary);
            font-weight: 700;
            font-size: 28px;
            text-align: center;
            position: relative;
            padding-bottom: 10px;
        }
        
        h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 4px;
            background: var(--primary);
            border-radius: 2px;
        }
        
        label {
            display: block;
            margin-top: 18px;
            font-weight: 600;
            color: var(--dark);
        }
        
        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            margin-top: 8px;
            border-radius: 8px;
            border: 1px solid var(--border);
            box-sizing: border-box;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(74, 108, 247, 0.2);
        }
        
        .two {
            display: flex;
            gap: 12px;
        }
        
        .two select, .two input {
            flex: 1;
        }
        
        .btn {
            margin-top: 25px;
            padding: 14px 20px;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(74, 108, 247, 0.2);
        }
        
        .btn:hover {
            background: #3a5bd9;
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(74, 108, 247, 0.3);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .error {
            background: #fff1f2;
            color: var(--danger);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #ffccd5;
            font-weight: 500;
        }
        
        fieldset {
            margin-top: 20px;
            border: 1px solid var(--border);
            padding: 20px;
            border-radius: 8px;
            background: var(--light);
        }
        
        legend {
            padding: 0 10px;
            font-weight: 600;
            color: var(--secondary);
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .back-link:hover {
            color: #3a5bd9;
            text-decoration: underline;
        }
        
        .form-group {
            margin-bottom: 5px;
        }
        
        .optional {
            color: var(--secondary);
            font-weight: normal;
        }
        
        footer {
            text-align: center;
            padding: 20px;
            color: var(--secondary);
            border-top: 1px solid var(--border);
            background: white;
            margin-top: 40px;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .header .container {
                flex-direction: column;
                gap: 15px;
            }
            
            nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
            }
            
            nav a {
                margin: 0;
            }
            
            .two {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <div class="box">
            <h2>Add Contact</h2>

            <?php if (!empty($errors)): ?>
                <div class="error">
                    <?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?>
                </div>
            <?php endif; ?>

            <form method="post" action="add_contact.php">
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($name) ?>" required>
                </div>

                <div class="form-group">
                    <label>Phone</label>
                    <div class="two">
                        <select name="country_code" aria-label="country code">
                            <option value="">No code</option>
                            <option value="+45" <?= ($country_code == '+45') ? 'selected' : '' ?>>+45 (DK)</option>
                            <option value="+1" <?= ($country_code == '+1') ? 'selected' : '' ?>>+1 (US/CA)</option>
                            <option value="+44" <?= ($country_code == '+44') ? 'selected' : '' ?>>+44 (UK)</option>
                            <option value="+91" <?= ($country_code == '+91') ? 'selected' : '' ?>>+91 (IN)</option>
                            <option value="+61" <?= ($country_code == '+61') ? 'selected' : '' ?>>+61 (AU)</option>
                            <option value="+971" <?= ($country_code == '+971') ? 'selected' : '' ?>>+971 (UAE)</option>
                        </select>

                        <input type="text" name="phone" placeholder="Local number" value="<?php echo htmlspecialchars($phone) ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Email <span class="optional">(optional)</span></label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($email) ?>">
                </div>

                <div class="form-group">
                    <label>Category</label>
                    <select name="group_id">
                        <option value="">-- Select Category --</option>
                        <?php foreach ($groups as $g): ?>
                            <option value="<?= (int)$g['id'] ?>" <?= ($group_id == $g['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($g['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <fieldset>
                    <legend>Address <span class="optional">(optional)</span></legend>
                    <div class="form-group">
                        <label>Street</label>
                        <input type="text" name="street" value="<?php echo htmlspecialchars($street) ?>">
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" name="city" value="<?php echo htmlspecialchars($city) ?>">
                    </div>
                    <div class="form-group">
                        <label>State</label>
                        <input type="text" name="state" value="<?php echo htmlspecialchars($state) ?>">
                    </div>
                    <div class="form-group">
                        <label>Postal Code</label>
                        <input type="text" name="postal" value="<?php echo htmlspecialchars($postal) ?>">
                    </div>
                </fieldset>

                <button type="submit" class="btn">Add Contact</button>
            </form>

            <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Contact Book - Stay Connected</p>
    </footer>
</body>
</html>