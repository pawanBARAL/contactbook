<?php 
// Load configuration and header
require 'config.php';
require 'header.php';
// Ensure user is logged in
require_login();

// Check if contact was added or deleted (for showing success messages)
$added = isset($_GET['added']);
$deleted = isset($_GET['deleted']);
// Get selected category/group from URL
$group_id = $_GET['group_id'] ?? '';

// Fetch user's contact groups for dropdown filter
$groupStmt = $pdo->prepare('SELECT id, name FROM groups WHERE user_id = ?');
$groupStmt->execute([$_SESSION['user_id']]);
$groups = $groupStmt->fetchAll();

// Fetch contacts with optional group filtering
if ($group_id !== '') {

    // Get contacts filtered by specific group
    $stmt = $pdo->prepare('SELECT c.*, a.street, a.city, a.state, a.postal_code, g.name AS group_name
                           FROM contacts c
                           LEFT JOIN address a ON c.id = a.contact_id
                           LEFT JOIN groups g ON c.group_id = g.id
                           WHERE c.user_id = ? AND c.group_id = ? AND c.deleted_at IS NULL
                           ORDER BY c.name ASC');
    $stmt->execute([$_SESSION['user_id'], $group_id]);
} else {
    // Get all contacts for user
    $stmt = $pdo->prepare('SELECT c.*, a.street, a.city, a.state, a.postal_code, g.name AS group_name
                           FROM contacts c
                           LEFT JOIN address a ON c.id = a.contact_id
                           LEFT JOIN groups g ON c.group_id = g.id
                           WHERE c.user_id = ? AND c.deleted_at IS NULL
                           ORDER BY c.name ASC');
    $stmt->execute([$_SESSION['user_id']]);
}

$contacts = $stmt->fetchAll();

// ⭐ NEW — Load favourite_settings
$settingsStmt = $pdo->prepare("SELECT * FROM favourite_settings WHERE user_id = ?");
$settingsStmt->execute([$_SESSION['user_id']]);
$settings = $settingsStmt->fetchAll(PDO::FETCH_ASSOC);

// Organise by contact_id
$settingsByContact = [];
foreach ($settings as $s) {
    $settingsByContact[$s['contact_id']] = $s;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Contacts - Contact Book</title>
  <link rel="stylesheet" href="assets/dashboard.css">
  <style>

    /* ===========================
       View Contacts - Cleaned Styles
       =========================== */

    /* Color scheme */
    :root {
      --primary: #4a6cf7;
      --primary-light: #eef2ff;
      --secondary: #6c757d;
      --success: #28a745;
      --danger: #dc3545;
      --light: #f8f9fa;
      --dark: #343a40;
      --border: #dee2e6;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    body {
      background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: var(--dark);
      line-height: 1.6;
      margin: 0;
      padding: 0;
      min-height: 100vh;
    }

    /* -----------------------------------------
       ❌ REMOVED HEADER + NAVIGATION CSS
       (.dash-header, nav, logo)
       ----------------------------------------- */

    .contacts-container {
      max-width: 1200px;
      margin: 30px auto;
      padding: 20px;
    }

    h2 {
      text-align: center;
      color: var(--primary);
      font-weight: 700;
      font-size: 32px;
      margin-bottom: 30px;
      position: relative;
      padding-bottom: 15px;
    }

    h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 4px;
      background: var(--primary);
      border-radius: 2px;
    }

    .message {
      padding: 12px 20px;
      border-radius: 8px;
      margin-bottom: 20px;
      text-align: center;
      font-weight: 500;
    }

    .success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    /* Search + Category filter bar */
    .search-filter-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      align-items: center;
      justify-content: space-between;
      background: white;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 2px 8px var(--shadow);
      margin-bottom: 30px;
    }

    select,
    input[type="text"] {
      padding: 10px 15px;
      border-radius: 8px;
      border: 1px solid var(--border);
      font-size: 16px;
      transition: all 0.3s ease;
    }

    select:focus,
    input[type="text"]:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(74, 108, 247, 0.2);
    }

    .manage-link {
      background: var(--primary);
      color: white;
      padding: 10px 15px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .manage-link:hover {
      background: #3a5bd9;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(74, 108, 247, 0.3);
    }

    #search {
      flex: 1;
      min-width: 250px;
      max-width: 400px;
    }

    /* Contact Grid */
    .contact-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 25px;
      margin-top: 20px;
      align-items: start; /* ⭐ FIX FOR YOUR ISSUE */
    }

    .contact-card {
      background: white;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 4px 12px var(--shadow);
      transition: all 0.3s ease;
      border-top: 4px solid var(--primary);
    }

    .contact-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    }

    .contact-card h3 {
      margin: 0 0 15px 0;
      color: var(--dark);
      font-size: 20px;
      font-weight: 600;
      border-bottom: 1px solid var(--border);
      padding-bottom: 10px;
    }

    .contact-card p {
      margin: 8px 0;
      display: flex;
      align-items: flex-start;
    }

    .contact-card p:before {
      margin-right: 10px;
      width: 20px;
      text-align: center;
    }

    .actions {
      margin-top: 20px;
      display: flex;
      gap: 10px;
    }

    .actions a {
      text-decoration: none;
      padding: 8px 15px;
      border-radius: 6px;
      font-weight: 500;
      transition: all 0.3s ease;
      flex: 1;
      text-align: center;
    }

    .actions a:first-child {
      background: var(--primary);
      color: white;
    }

    .actions a:first-child:hover {
      background: #3a5bd9;
      transform: translateY(-2px);
    }

    .actions a.delete {
      background: var(--danger);
      color: white;
    }

    .actions a.delete:hover {
      background: #c82333;
      transform: translateY(-2px);
    }

    /* Hidden class for search filtering */
    .hidden {
      display: none !important;
    }

    /* No contacts message */
    .no-contacts {
      text-align: center;
      margin: 40px 0;
      padding: 30px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 12px var(--shadow);
    }

    .no-contacts a {
      color: var(--primary);
      text-decoration: none;
      font-weight: 500;
    }

    .no-contacts a:hover {
      text-decoration: underline;
    }

    /* Modal */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      animation: fadeIn 0.3s ease;
    }

    .modal-content {
      background-color: white;
      margin: 15% auto;
      padding: 0;
      border-radius: 12px;
      width: 90%;
      max-width: 450px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
      animation: slideIn 0.3s ease;
      overflow: hidden;
      border: none;
    }

    .modal-header {
      background: white;
      padding: 25px 25px 0;
      text-align: center;
    }

    .modal-header h3 {
      margin: 0;
      font-size: 24px;
      font-weight: 700;
      color: var(--dark);
      position: relative;
      padding-bottom: 15px;
    }

    .modal-header h3:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 50px;
      height: 3px;
      background: var(--primary);
      border-radius: 2px;
    }

    .modal-icon {
      font-size: 48px;
      margin-bottom: 15px;
      color: var(--danger);
    }

    .modal-body {
      padding: 25px;
      text-align: center;
    }

    .modal-body p {
      margin: 0 0 15px 0;
      color: var(--dark);
      font-size: 16px;
      line-height: 1.6;
    }

    .contact-name-highlight {
      color: var(--primary);
      font-weight: 600;
      background: var(--primary-light);
      padding: 2px 8px;
      border-radius: 4px;
    }

    .warning-text {
      color: var(--danger);
      font-size: 14px;
      font-weight: 500;
      background: #fff1f2;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ffccd5;
      margin-top: 15px;
    }

    .modal-footer {
      padding: 0 25px 25px;
      display: flex;
      gap: 12px;
      justify-content: center;
    }

    .modal-btn {
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      min-width: 100px;
      font-size: 15px;
    }

    .modal-btn.cancel {
      background: var(--light);
      color: var(--secondary);
      border: 1px solid var(--border);
    }

    .modal-btn.cancel:hover {
      background: #e9ecef;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px var(--shadow);
    }

    .modal-btn.confirm {
      background: var(--danger);
      color: white;
      box-shadow: 0 4px 6px rgba(220, 53, 69, 0.2);
    }

    .modal-btn.confirm:hover {
      background: #c82333;
      transform: translateY(-2px);
      box-shadow: 0 6px 8px rgba(220, 53, 69, 0.3);
    }

    /* Animations */
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateY(-50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* Responsive */
    @media (max-width: 768px) {

      /* Removed old header responsive rules */

      .search-filter-bar {
        flex-direction: column;
        align-items: stretch;
      }

      #search {
        max-width: none;
      }

      .contact-grid {
        grid-template-columns: 1fr;
      }

      .modal-content {
        margin: 20% auto;
        width: 95%;
      }

      .modal-footer {
        flex-direction: column;
      }

      .modal-btn {
        width: 100%;
      }
    }
  </style>
</head>

<body>

  <main class="contacts-container">
    <h2>Your Contacts</h2>

    <?php if ($added): ?>
      <div class="message success">✅ Contact added successfully.</div>
    <?php endif; ?>
    
    <?php if ($deleted): ?>
      <div class="message success">🗑️ Contact deleted successfully.</div>
    <?php endif; ?>

    <div class="search-filter-bar">
      <form method="get" style="display:flex; gap:15px; align-items:center;">
        <select name="group_id" onchange="this.form.submit()">
          <option value="">All Categories</option>
          <?php foreach ($groups as $g): ?>
            <option value="<?= $g['id'] ?>" <?= ($group_id == $g['id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($g['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </form>
      
      <a href="manage_groups.php" class="manage-link">⚙️ Manage Categories</a>
      
      <input type="text" id="search" placeholder="Search contacts by name, phone, or email...">
    </div>

    <?php if (empty($contacts)): ?>
      <div class="no-contacts">
        <p>No contacts found. <a href="add_contact.php">Add one here</a>.</p>
      </div>
    <?php else: ?>
    
      <div class="contact-grid" id="contactGrid">

        <?php foreach ($contacts as $c): ?>
          <div class="contact-card" 
               data-name="<?= strtolower(htmlspecialchars($c['name'])); ?>" 
               data-phone="<?= strtolower(htmlspecialchars((($c['country_code'] ?? '') . ' ' . ($c['phone'] ?? '')))); ?>" 
               data-email="<?= strtolower(htmlspecialchars($c['email'])); ?>">

            <h3>
              <?= htmlspecialchars($c['name']); ?>
              

                <?php

                // My part: favourite contact feature.
               // If is_favourite = 1, It show a gold star and clicking removes it.
               // If is_favourite = 0, It show an empty star and clicking adds it.
                // The click sends the contact ID to toggle_favourite.php which updates the database.
                //it works as ADD BUTTON
                                                                                                                                                                                      
                 if ($c['is_favourite'] == 1): ?>
                  <a href="toggle_favourite.php?id=<?= $c['id']; ?>" 
                    class="star-icon"
                    title="Remove from favourites"
                    style="float:right; font-size:32px; color:gold; 
                            text-decoration:none; filter:drop-shadow(0 0 8px gold);">
                    ★
                  </a>
                <?php else: ?>

                  <a href="toggle_favourite.php?id=<?= $c['id']; ?>" 
                    class="star-icon"
                    title="Add to favourites"
                    style="float:right; font-size:32px; color:#ccc; 
                            text-decoration:none; filter:drop-shadow(0 0 5px #999);">
                    ☆
                  </a>
              <?php endif; ?>

            </h3>

            <p>📞 <?= htmlspecialchars(trim((($c['country_code'] ?? '') . ' ' . ($c['phone'] ?? '')))); ?></p>
            <p>✉️ <?= htmlspecialchars($c['email'] ?: '—'); ?></p>
            <p>📂 <?= htmlspecialchars($c['group_name'] ?? 'Uncategorized'); ?></p>
            <p>📍 
              <?php 
                $address = array_filter([$c['street'], $c['city'], $c['state'], $c['postal_code']]);
                echo htmlspecialchars(empty($address) ? '—' : implode(', ', $address));
              ?>
            </p>

            <!-- ⭐ NEW: Extra Favourite Settings -->
<?php 
if (
    $c['is_favourite'] == 1 &&
    !empty($settingsByContact[$c['id']]) &&
    (
        $settingsByContact[$c['id']]['is_urgent'] == 1 ||
        $settingsByContact[$c['id']]['priority_score'] !== null ||
        $settingsByContact[$c['id']]['colour_tag'] !== "" ||
        $settingsByContact[$c['id']]['description'] !== ""
    )
) {
    $s = $settingsByContact[$c['id']];
    echo '<div style="margin-top:15px; padding:12px; background:#f8f9ff; border-left:4px solid var(--primary); border-radius:8px;">';

    echo '<strong>⭐ Extra Favourite Settings</strong><br><br>';

    if ($s["is_urgent"] == 1) {
        echo '<p>🔥 <strong>Urgent Favourite</strong></p>';
    }

    if ($s["priority_score"] !== null && $s["priority_score"] !== "") {
        echo '<p>🏆 Priority Score: <strong>' . htmlspecialchars($s["priority_score"]) . '</strong></p>';
    }

    if (!empty($s["colour_tag"])) {
        echo '<p>🎨 Colour Tag: <strong>' . htmlspecialchars($s["colour_tag"]) . '</strong></p>';
    }

    if (!empty($s["description"])) {
        echo '<p>📝 Description: ' . htmlspecialchars($s["description"]) . '</p>';
    }

    echo '</div>';
}
?>


<!-- Actions -->

            <div class="actions">
              <a href="edit_contact.php?id=<?= $c['id']; ?>">✏️ Edit</a>
              <a href="#" class="delete" data-contact-id="<?= $c['id']; ?>" data-contact-name="<?= htmlspecialchars($c['name']); ?>">🗑️ Delete</a>
            </div>

          </div>
        <?php endforeach; ?>

      </div>
    <?php endif; ?>

  </main>

  <!-- Custom Confirmation Modal -->
  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <div class="modal-icon">🗑️</div>
        <h3>Delete Contact</h3>
      </div>

      <div class="modal-body">
        <p></p>
        <div class="warning-text">
          Are you sure you want to delete <span class="contact-name-highlight" id="contactName"></span>?
        </div>
      </div>

      <div class="modal-footer">
        <button class="modal-btn cancel">Cancel</button>
        <button class="modal-btn confirm">Delete Contact</button>
      </div>

    </div>
  </div>

  <footer>
    <p>&copy; 2025 Contact Book - Manage with ease</p>
  </footer>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const searchInput = document.getElementById('search');
      const cards = document.querySelectorAll('.contact-card');
      const deleteModal = document.getElementById('deleteModal');
      const contactNameSpan = document.getElementById('contactName');
      const cancelBtn = document.querySelector('.modal-btn.cancel');
      const confirmBtn = document.querySelector('.modal-btn.confirm');
      
      let contactToDelete = null;

      // Search functionality FILTERING
      searchInput.addEventListener('input', () => {
        const query = searchInput.value.trim().toLowerCase();
        cards.forEach(card => {
          const name = card.dataset.name;
          const phone = card.dataset.phone;
          const email = card.dataset.email;
          const matches = name.includes(query) || phone.includes(query) || email.includes(query);
          card.classList.toggle('hidden', !matches);
        });
      });

      // Delete button click handlers
      document.querySelectorAll('.actions a.delete').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          const contactId = btn.dataset.contactId;
          const contactName = btn.dataset.contactName;
          
          contactToDelete = contactId;
          contactNameSpan.textContent = contactName;
          deleteModal.style.display = 'block';
        });
      });

      // Modal button handlers
      cancelBtn.addEventListener('click', () => {
        deleteModal.style.display = 'none';
        contactToDelete = null;
      });

      confirmBtn.addEventListener('click', () => {
        if (contactToDelete) {
          window.location.href = `delete_contact.php?id=${contactToDelete}`;
        }
      });

      // Close modal when clicking outside
      window.addEventListener('click', (e) => {
        if (e.target === deleteModal) {
          deleteModal.style.display = 'none';
          contactToDelete = null;
        }
      });

      // Close modal with Escape key
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && deleteModal.style.display === 'block') {
          deleteModal.style.display = 'none';
          contactToDelete = null;
        }
      });
    });
  </script>

</body>
</html>
