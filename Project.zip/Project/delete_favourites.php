<?php
require 'config.php';         
require_login();              
ob_start();                   


// -------------------------------------------------------------
// VALIDATION: Ensure an ID is provided in the URL
// -------------------------------------------------------------
if (!isset($_GET['id'])) {
    header("Location: favourites.php");   // Safe redirect if ID missing
    exit;
}

$id = (int)$_GET['id'];   // Convert ID to integer for security


// --------------------------------------------------------------------
// BACKEND VALIDATION + SECURITY CHECK
// Ensure:
//   ✔ The contact exists
//   ✔ It belongs to the logged-in user
//   ✔ It is actually marked as favourite
// This prevents unauthorized delete attempts
// --------------------------------------------------------------------
$stmt = $pdo->prepare("
    SELECT id FROM contacts 
    WHERE id = ? AND user_id = ? AND is_favourite = 1
");
$stmt->execute([$id, $_SESSION['user_id']]);
$contact = $stmt->fetch();

if (!$contact) {
    // If no matching favourite contact found → block access
    // Prevents one user from removing another user's favourite
    header("Location: favourites.php?error=notfound");
    exit;
}


// -------------------------------------------------------------
// REMOVE FROM FAVOURITES (DELETE functionality for favourites)
// Instead of deleting the entire contact permanently,
// we only update is_favourite = 0 so the data is preserved
// -------------------------------------------------------------
$stmt = $pdo->prepare("
    UPDATE contacts 
    SET is_favourite = 0
    WHERE id = ? AND user_id = ?
");
$stmt->execute([$id, $_SESSION['user_id']]);
// Contact is now removed from favourites (DELETE functionality)


// -------------------------------------------------------------
// REDIRECT BACK WITH SUCCESS MESSAGE
// -------------------------------------------------------------
header("Location: favourites.php?removed=1");
exit;

ob_end_flush();  
?>